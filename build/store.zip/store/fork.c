int main(){
	int pid;
	int pid2;

	if(fork()&&fork()){
		fork();
	}

	printf("pid=%d\n", pid);
	wait(NULL);
}